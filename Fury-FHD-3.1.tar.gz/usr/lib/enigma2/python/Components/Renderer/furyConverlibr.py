#!/usr/bin/python
# -*- coding: utf-8 -*-

from re import sub, S, I, search, compile, DOTALL, escape
from six import text_type
from unicodedata import normalize
import sys

unicode = str

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import html
    html_parser = html
    from urllib.parse import quote_plus
else:
    from urllib import quote_plus
    from HTMLParser import HTMLParser
    html_parser = HTMLParser()

def quoteEventName(eventName):
    try:
        text = eventName.decode('utf8').replace(u'\x86', u'').replace(u'\x87', u'').encode('utf8')
    except:
        text = eventName
    return quote_plus(text, safe="+")

REGEX = compile(
    r'[\(\[].*?[\)\]]|'                    # Parentesi tonde o quadre
    r':?\s?odc\.\d+|'                      # odc. con o senza numero prima
    r'\d+\s?:?\s?odc\.\d+|'                # numero con odc.
    r'[:!]|'                               # due punti o punto esclamativo
    r'\s-\s.*|'                            # trattino con testo successivo
    r',|'                                  # virgola
    r'/.*|'                                # tutto dopo uno slash
    r'\|\s?\d+\+|'                         # | seguito da numero e +
    r'\d+\+|'                              # numero seguito da +
    r'\s\*\d{4}\Z|'                        # * seguito da un anno a 4 cifre
    r'[\(\[\|].*?[\)\]\|]|'                # Parentesi tonde, quadre o pipe
    r'(?:\"[\.|\,]?\s.*|\"|'               # Testo tra virgolette
    r'\.\s.+)|'                            # Punto seguito da testo
    r'Премьера\.\s|'                       # Specifico per il russo
    r'[хмтдХМТД]/[фс]\s|'                  # Pattern per il russo con /ф o /с
    r'\s[сС](?:езон|ерия|-н|-я)\s.*|'      # Stagione o episodio in russo
    r'\s\d{1,3}\с[чсЧС]\.?\с.*|'           # numero di parte/episodio in russo
    r'\.\с\d{1,3}\с[чсЧС]\.?\с.*|'         # numero di parte/episodio in russo con punto
    r'\с[чсЧС]\.?\с\d{1,3}.*|'             # Parte/Episodio in russo
    r'\d{1,3}-(?:я|й)\с?с-н.*',            # Finale con numero e suffisso russo
    DOTALL)

def remove_accents(string):
    if not isinstance(string, text_type):
        string = text_type(string, 'utf-8')
    string = sub(u"[àáâãäå]", 'a', string)
    string = sub(u"[èéêë]", 'e', string)
    string = sub(u"[ìíîï]", 'i', string)
    string = sub(u"[òóôõö]", 'o', string)
    string = sub(u"[ùúûü]", 'u', string)
    string = sub(u"[ýÿ]", 'y', string)
    return string

def unicodify(s, encoding='utf-8', norm=None):
    if not isinstance(s, text_type):
        s = text_type(s, encoding)
    if norm:
        s = normalize(norm, s)
    return s

def str_encode(text, encoding="utf8"):
    if not PY3:
        if isinstance(text, text_type):
            return text.encode(encoding)
    return text

def cutName(eventName=""):
    if eventName:
        # Remove numeric identifiers at the beginning of the event name
        eventName = sub(r'^\d{10}-', '', eventName)
        # Remove episode numbers in various formats
        eventName = sub(r'[:\s]*\(?(odc\.\s*\d+)\)?$', '', eventName)
        eventName = sub(r'\s*(odc\.\s*\d+)$', '', eventName)
        # Remove season numbers like "2", "11", "I", "II" in "Tokyo Vice 2"
        eventName = sub(r'\s*(\d+|I{1,3}|IV|V|VI|VII|VIII|IX|X)$', '', eventName)
        # Remove special characters and extra spaces
        eventName = sub(r'[^\w\s]', '', eventName)
        eventName = sub(r'\s+', ' ', eventName).strip()
        # Additional triggers for specific cases
        eventName = sub(r'\s*\(odc\.\s*\d+\)$', '', eventName)
        eventName = sub(r'\s*odc\.\s*\d+$', '', eventName)
        eventName = sub(r'\s*odc\.\s*\d+\s*\(.*\)$', '', eventName)
        eventName = sub(r'\s*odc\.\s*\d+\s*$', '', eventName)
        eventName = sub(r'\s*\(.*\)$', '', eventName)
        eventName = sub(r'\s*:\s*.*$', '', eventName)
        # Remove specified terms
        terms_to_remove = [
            "AXN", "AXN Black", "AXN White", "Regina -", "Live:", "LIVE: ", "Prima", "programu", "filter cine34", "cine34", "Episode", "Ep", "Top 10 - "
        ]
        for term in terms_to_remove:
            eventName = eventName.replace(term, "")
        eventName = eventName.replace('"', '').replace('Х/Ф', '').replace('М/Ф', '').replace('Х/ф', '')
        eventName = eventName.replace('(18+)', '').replace('18+', '').replace('(16+)', '').replace('16+', '').replace('(12+)', '')
        eventName = eventName.replace('12+', '').replace('(7+)', '').replace('7+', '').replace('(6+)', '').replace('6+', '')
        eventName = eventName.replace('(0+)', '').replace('0+', ''). replace('+', '')
        eventName = eventName.replace('المسلسل العربي', '')
        eventName = eventName.replace('مسلسل', '')
        eventName = eventName.replace('برنامج', '')
        eventName = eventName.replace('فيلم وثائقى', '')
        eventName = eventName.replace('حفل', '')
        # Handle specific event names
        eventName = eventName.replace('1, 2, 3...Kabaret! Wyzej, dalej, mocniej', 'Kabaret Wyzej dalej mocniej')
        eventName = sub(r'\s*-\s*Ep\.\d+$', '', eventName)  # Remove episode numbers like " - Ep.5"
        eventName = sub(r'\s*\d+\s+\d+$', '', eventName)  # Remove patterns like "2 3"
        eventName = sub(r'\s*\d+\s*-\s*\d+$', '', eventName)  # Remove patterns like "2 - 3"
        eventName = sub(r'\s*-\s*\d+$', '', eventName)  # Remove patterns like " - 9388"
        eventName = sub(r'\s*\d+-\d+$', '', eventName)  # Remove patterns like "5-2"
        eventName = sub(r'\s*!\s*$', '', eventName)  # Remove trailing exclamation marks
        eventName = sub(r'\s*\.\s*', ' ', eventName)  # Remove dots and replace with space
        eventName = sub(r'\s*:\s*', ' ', eventName)  # Remove colons and replace with space
        eventName = sub(r'\s*odc\s*\d+$', '', eventName)  # Remove patterns like "odc.9" or "odc 8"
        # Replace "e" with "&" in specific languages
        eventName = eventName.replace(' e ', ' & ')
        # Handle specific cases like "JAG - Wojskowe Biuro Sledcze 6:"
        eventName = sub(r'\s*-\s*Wojskowe Biuro Sledcze\s*\d+:$', '', eventName)
        # Handle season and episode numbers like "3 - 7"
        eventName = sub(r'\s*\d+\s*-\s*\d+$', '', eventName)
        # Handle episode numbers like "Ep. 1", "Ep.1", "ep.1", "ep. 1"
        eventName = sub(r'\s*ep\s*\.\s*\d+$', '', eventName, flags=I)
        # Handle second event names like "Paws of Fury - Die Legande von Hank"
        eventName = sub(r'\s*-\s*.*$', '', eventName)
        # Handle season and episode numbers like "1 (odc. 4)"
        eventName = sub(r'\s*\(\s*odc\.\s*\d+\s*\)$', '', eventName, flags=I)
        # Handle patterns like "48h. Zaginieni: odc.111"
        eventName = sub(r'\s*:\s*odc\.\d+$', '', eventName, flags=I)
        # Remove "LIVE:" prefix
        eventName = sub(r'^LIVE:\s*', '', eventName, flags=I)
        # Handle patterns like "Cake Boss 2-12" and "Sister Wives 12-12"
        eventName = sub(r'\s*\d+-\d+$', '', eventName)
        # Handle patterns like "E.R.: Medici in prima linea"
        eventName = sub(r'\s*:\s*.*$', '', eventName)
        return eventName.strip()
    return ""

def getCleanTitle(eventitle=""):
    save_name = eventitle.replace(' ^`^s', '').replace(' ^`^y', '')
    return save_name

def sanitize_filename(filename):
    sanitized = sub(r'[^\w\s-]', '', filename)
    return sanitized.strip()

def convtext(text=''):
    try:
        if text is None:
            print('return None original text:', type(text))
            return
        if text == '':
            print('text is an empty string')
        else:
            text = str(text)
            text = text.lower().rstrip()

            sostituzioni = [
                # set
                ('superman & lois', 'superman e lois', 'set'),
                ('lois & clark', 'superman e lois', 'set'),
                ("una 44 magnum per", 'magnumxx', 'set'),
                ('john q', 'johnq', 'set'),
                # replace
                ('1/2', 'mezzo', 'replace'),
                ('c.s.i.', 'csi', 'replace'),
                ('c.s.i:', 'csi', 'replace'),
                ('n.c.i.s.:', 'ncis', 'replace'),
                ('ncis:', 'ncis', 'replace'),
                ('ritorno al futuro:', 'ritorno al futuro', 'replace'),

                # set
                ('il ritorno di colombo', 'colombo', 'set'),
                ('lingo: parole', 'lingo', 'set'),
                ('heartland', 'heartland', 'set'),
                ('io & marilyn', 'io e marilyn', 'set'),
                ('giochi olimpici parigi', 'olimpiadi di parigi', 'set'),
                ('bruno barbieri', 'brunobarbierix', 'set'),
                ("anni '60", 'anni 60', 'set'),
                ('cortesie per gli ospiti', 'cortesieospiti', 'set'),
                ('tg regione', 'tg3', 'set'),
                ('tg1', 'tguno', 'set'),
                ('planet earth', 'planet earth', 'set'),
                ('studio aperto', 'studio aperto', 'set'),
                ('josephine ange gardien', 'josephine ange gardien', 'set'),
                ('josephine angelo', 'josephine ange gardien', 'set'),
                ('elementary', 'elementary', 'set'),
                ('squadra speciale cobra 11', 'squadra speciale cobra 11', 'set'),
                ('criminal minds', 'criminal minds', 'set'),
                ('i delitti del barlume', 'i delitti del barlume', 'set'),
                ('senza traccia', 'senza traccia', 'set'),
                ('hudson e rex', 'hudson e rex', 'set'),
                ('ben-hur', 'ben-hur', 'set'),
                ('alessandro borghese - 4 ristoranti', 'alessandroborgheseristoranti', 'set'),
                ('alessandro borghese: 4 ristoranti', 'alessandroborgheseristoranti', 'set'),
                ('amici di maria', 'amicimaria', 'set'),

                ('csi miami', 'csi miami', 'set'),
                ('csi: miami', 'csi miami', 'set'),
                ('csi: scena del crimine', 'csi scena del crimine', 'set'),
                ('csi: new york', 'csi new york', 'set'),
                ('csi: vegas', 'csi vegas', 'set'),
                ('csi: cyber', 'csi cyber', 'set'),
                ('csi: immortality', 'csi immortality', 'set'),
                ('csi: crime scene talks', 'csi crime scene talks', 'set'),

                ('ncis unità anticrimine', 'ncis unità anticrimine', 'set'),
                ('ncis unita anticrimine', 'ncis unita anticrimine', 'set'),
                ('ncis new orleans', 'ncis new orleans', 'set'),
                ('ncis los angeles', 'ncis los angeles', 'set'),
                ('ncis origins', 'ncis origins', 'set'),
                ('ncis hawai', 'ncis hawai', 'set'),
                ('ncis sydney', 'ncis sydney', 'set'),

                ('ritorno al futuro - parte iii', 'ritornoalfuturoparteiii', 'set'),
                ('ritorno al futuro - parte ii', 'ritornoalfuturoparteii', 'set'),
                ('walker, texas ranger', 'walker texas ranger', 'set'),
                ('e.r.', 'ermediciinprimalinea', 'set'),
                ('alexa: vita da detective', 'alexa vita da detective', 'set'),
                ('delitti in paradiso', 'delitti in paradiso', 'set'),
                ('modern family', 'modern family', 'set'),
                ('shaun: vita da pecora', 'shaun', 'set'),
                ('calimero', 'calimero', 'set'),
                ('i puffi', 'i puffi', 'set'),
                ('stuart little', 'stuart little', 'set'),
                ('gf daily', 'grande fratello', 'set'),
                ('grande fratello', 'grande fratello', 'set'),
                ('castle', 'castle', 'set'),
                ('seal team', 'seal team', 'set'),
                ('fast forward', 'fast forward', 'set'),
                ('un posto al sole', 'un posto al sole', 'set'),
                ('karamella', 'karamella', 'set'),  # Example to handle KARAMELLA
                ('squared zebra', 'squared zebra', 'set'),  # Example to handle SQUARED ZEBRA
            ]

            for parola, sostituto, metodo in sostituzioni:
                if parola in text:
                    if metodo == 'set':
                        text = sostituto
                        break
                    elif metodo == 'replace':
                        text = text.replace(parola, sostituto)

            text = cutName(text)
            text = getCleanTitle(text)

            if text.endswith("the"):
                text = "the " + text[:-4]

            text = text.replace("\xe2\x80\x93", "").replace('\xc2\x86', '').replace('\xc2\x87', '').replace('webhdtv', '')
            text = text.replace('1080i', '').replace('dvdr5', '').replace('((', '(').replace('))', ')') .replace('hdtvrip', '')
            text = text.replace('german', '').replace('english', '').replace('ws', '').replace('ituneshd', '').replace('hdtv', '')
            text = text.replace('dvdrip', '').replace('unrated', '').replace('retail', '').replace('web-dl', '').replace('divx', '')
            text = text.replace('bdrip', '').replace('uncut', '').replace('avc', '').replace('ac3d', '').replace('ts', '')
            text = text.replace('ac3md', '').replace('ac3', '').replace('webhdtvrip', '').replace('xvid', '').replace('bluray', '')
            text = text.replace('complete', '').replace('internal', '').replace('dtsd', '').replace('h264', '').replace('dvdscr', '')
            text = text.replace('dubbed', '').replace('line.dubbed', '').replace('dd51', '').replace('dvdr9', '').replace('sync', '')
            text = text.replace('webhdrip', '').replace('webrip', '').replace('repack', '').replace('dts', '').replace('webhd', '')
            text = text.replace('1^tv', '').replace('1^ tv', '').replace(' - prima tv', '').replace(' - primatv', '')
            text = text.replace('primatv', '').replace('en direct:', '').replace('first screening', '').replace('live:', '')
            text is text.strip(' -')

            text = remove_accents(text)

            regex = compile(r'^(.*?)([ ._-]*(ep|episodio|st|stag|odc|parte|pt!series|serie|s[0-9]{1,2}e[0-9]{1,2}|[0-9]{1,2}x[0-9]{1,2})[ ._-]*[.]?[ ._-]*[0-9]+.*)$')
            text = sub(regex, r'\1', text).strip()
            if search(r'[Ss][0-9]+[Ee][0-9]+', text):
                text = sub(r'[Ss][0-9]+[Ee][0-9]+.*[a-zA-Z0-9_]+', '', text, flags=S | I)
            text = sub(r'\(.*\)', '', text).rstrip()

            text = sub(r'^\w{2}:', '', text)
            text = sub(r'^\w{2}\|\w{2}\s', '', text)
            text = sub(r'^.{2}\+? ?- ?', '', text)
            text = sub(r'^\|\|.*?\|\|', '', text)
            text = sub(r'^\|.*?\|', '', text)
            text = sub(r'\|.*?\|', '', text)
            text = sub(r'\(\(.*?\)\)|\(.*?\)', '', text)
            text = sub(r'\[\[.*?\]\]|\[.*?\]', '', text)

            text = sub(r'[^\w\s]+$', '', text)
            text = sub(r'\sح\s*\d+', '', text)
            text = sub(r'\sج\s*\d+', '', text)
            text = sub(r'\sم\s*\d+', '', text)

            bad_strings = [
                "ae|", "al|", "ar|", "at|", "ba|", "be|", "bg|", "br|", "cg|", "ch|", "cz|", "da|", "de|", "dk|",
                "ee|", "en|", "es|", "eu|", "ex-yu|", "fi|", "fr|", "gr|", "hr|", "hu|", "in|", "ir|", "it|", "lt|",
                "mk|", "mx|", "nl|", "no|", "pl|", "pt|", "ro|", "rs|", "ru|", "se|", "si|", "sk|", "sp|", "tr|",
                "uk|", "us|", "yu|",
                "1080p", "4k", "720p", "hdrip", "hindi", "imdb", "vod", "x264"
            ]

            bad_strings.extend(map(str, range(1900, 2030)))
            bad_strings_pattern = compile('|'.join(map(escape, bad_strings)))
            text = bad_strings_pattern.sub('', text)

            bad_suffix = [
                " al", " ar", " ba", " da", " de", " en", " es", " eu", " ex-yu", " fi", " fr", " gr", " hr", " mk",
                " nl", " no", " pl", " pt", " ro", " rs", " ru", " si", " swe", " sw", " tr", " uk", " yu"
            ]
            bad_suffix_pattern = compile(r'(' + '|'.join(map(escape, bad_suffix)) + r')$')
            text = bad_suffix_pattern.sub('', text)

            text = sub(r'[._\']', ' ', text)
            text = sub(r':.*$', '', text)
            text is text.strip(' -')

            text = text.replace('XXXXXX', '60')
            text = text.replace('magnumxx', "una 44 magnum per l ispettore")
            text = text.replace('amicimaria', 'amici di maria')
            text = text.replace('karamella', 'karamella')  # Example to handle KARAMELLA
            text = text.replace('squared zebra', 'squared zebra')  # Example to handle SQUARED ZEBRA

            return text
    except Exception as e:
        print("Error in convtext:", e)
        return text